# Texture-blocks 
Over 1,000 texture blocks for building.
> [!NOTE]
> If you do not speak the Java programming language, then we have given you the opportunity to take part in editing the code of our mod using the software - Mcreator.
