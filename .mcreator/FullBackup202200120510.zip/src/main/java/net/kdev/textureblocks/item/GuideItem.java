
package net.kdev.textureblocks.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.UseAction;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.kdev.textureblocks.itemgroup.TextureBlocksItemGroup;
import net.kdev.textureblocks.TextureBlocksModElements;

@TextureBlocksModElements.ModElement.Tag
public class GuideItem extends TextureBlocksModElements.ModElement {
	@ObjectHolder("texture_blocks:guide")
	public static final Item block = null;

	public GuideItem(TextureBlocksModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(TextureBlocksItemGroup.tab).maxStackSize(64).rarity(Rarity.EPIC));
			setRegistryName("guide");
		}

		@Override
		public UseAction getUseAction(ItemStack itemstack) {
			return UseAction.EAT;
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getUseDuration(ItemStack itemstack) {
			return 32;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
